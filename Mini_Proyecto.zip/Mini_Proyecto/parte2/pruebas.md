# Documentación de Pruebas y Memoria - Parte 2 (Tema 5B)

## 🚀 Instrucciones para abrir la aplicación y ejecutar pruebas
1. Abre la carpeta `parte2/` en tu editor de código (por ejemplo, VS Code).
2. Inicia la extensión **Live Server** sobre `index.html` o ábrelo directamente en un navegador moderno.
3. **Pruebas automatizadas (`pruebas.js`):** Abre la consola de desarrollador del navegador (`F12` > pestaña *Consola*) para verificar que todos los test unitarios de las expresiones regulares pasan sin errores.
4. **Pruebas de integración:** Interactúa con cada uno de los cinco formularios y la demostración final de `pattern` siguiendo los casos documentados a continuación.

---

## 📋 Casos de Prueba Mínimos (Integración y RegEx)

### 1. Nombre y normalización
* **Prueba 1.1: Normalización de espacios exteriores e interiores**
  * **Entrada:** `"   Ana    López  "`
  * **Resultado esperado:** Se normaliza internamente a `"Ana López"` (9 caracteres) mediante `replace()`, cumple el formato de letras permitidas y el rango de 4 a 50 caracteres. Válido.
  * **Resultado obtenido:** Correcto. El resumen muestra `"Ana López"`.
  * **Corrección realizada:** Ninguna.

* **Prueba 1.2: Caracteres no permitidos y límites de longitud**
  * **Entrada:** `"Ana2 López"` (contiene número) y `"   Ana   "` (longitud 3 tras normalizar).
  * **Resultado esperado:** Ambos casos deben ser rechazados con mensaje de error accesible junto al campo.
  * **Resultado obtenido:** Correcto. Se muestra error de formato en el primer caso y de longitud mínima en el segundo.
  * **Corrección realizada:** Ninguna.

---

### 2. Usuario y contraseña (repetición de pruebas)
* **Prueba 2.1: Formato de Usuario (Intento 1 y 2)**
  * **Entrada:** `"ana77"` (válido), `"7ana7"` (empieza por cifra, inválido), `"ana_7"` (contiene guion bajo, inválido), `"ana1"` (4 caracteres, límite inferior inválido).
  * **Resultado esperado:** `"ana77"` es aceptado; los demás son rechazados sin alteración por bandera `g` en repeticiones.
  * **Resultado obtenido:** Correcto tanto en la primera como en la segunda ejecución consecutiva.
  * **Corrección realizada:** Ninguna.

* **Prueba 2.2: Formato de Contraseña (Intento 1 y 2)**
  * **Entrada:** `"Clave_12"` (válida), `"1Clave_2"` (empieza por número, inválida), `"Clave-12"` (guion medio no permitido, inválida), `"Clave_1"` (7 caracteres, límite inferior inválido).
  * **Resultado esperado:** `"Clave_12"` es aceptada; el resto rechazada sin aplicar `trim()`.
  * **Resultado obtenido:** Correcto en ambas ejecuciones.
  * **Corrección realizada:** Ninguna.

---

### 3. Teléfono y códigos de identificación
* **Prueba 3.1: Formato estricto de Teléfono español**
  * **Entrada:** `"+34 612 345 678"` (válido), `"34 612 345 678"` (sin `+`), `"+34612345678"` (sin espacios), `"+34 512 345 678"` (primera cifra nacional `5`), `"+34 612 345 6789"` (una cifra de más).
  * **Resultado esperado:** Únicamente el primer caso es válido; los cuatro restantes son rechazados.
  * **Resultado obtenido:** Correcto.
  * **Corrección realizada:** Ninguna.

* **Prueba 3.2: Códigos de Servicio y Referencias de Cita**
  * **Entrada:** `"DEP-007"` y `"CITA-0001"` (válidos); `"dep-007"` (minúsculas), `"XCITA-0001"` (prefijo extra) y `"RES-001"` (solo 3 cifras).
  * **Resultado esperado:** Aceptar `"DEP-007"` y `"CITA-0001"`; rechazar el resto por incumplir anclas o mayúsculas.
  * **Resultado obtenido:** Correcto.
  * **Corrección realizada:** Ninguna.

---

### 4. Métodos de texto (`match` y `split`)
* **Prueba 4.1: Extracción de cifras en Testimonios**
  * **Entrada:** `"Hay 12 clases y 3 pistas"` y `"Un club excelente sin números"`.
  * **Resultado esperado:** El primer texto devuelve `["12", "3"]` en el contenedor de resultados; el segundo devuelve `[]`.
  * **Resultado obtenido:** Correcto.
  * **Corrección realizada:** Ninguna.

* **Prueba 4.2: Separación de etiquetas en Noticias**
  * **Entrada:** `"club, salud,, verano"`, `"   "` (vacío) y `", , "`.
  * **Resultado esperado:** El primer caso genera el array limpio `["club", "salud", "verano"]` (3 etiquetas); los casos vacíos o solo con comas devuelven `[]`.
  * **Resultado obtenido:** Correcto.
  * **Corrección realizada:** Ninguna.

---

### 5. Integración con reglas de la Parte 1
* **Prueba 5.1: Combinación de formato válido con errores de negocio**
  * **Entrada:** Introducir un código `"DEP-007"` válido, pero una duración de `20` minutos (no múltiplo de 15) o una edad de `17` años en socios.
  * **Resultado esperado:** El formulario no se envía aunque la RegEx sea correcta; al corregir la duración a `30` o la edad a `18`, desaparecen los errores y se muestra el resumen simulado.
  * **Resultado obtenido:** Correcto.
  * **Corrección realizada:** Ninguna.

---

## 🧠 Memoria Técnica Breve

### Explicación de patrones y banderas
* **Nombre (`/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+(?: [A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+)*$/`):** Usa anclas `^` y `$` para exigir el valor completo. Permite una o más letras del conjunto permitido seguidas de cero o más grupos compuestos por un único espacio y otra palabra. Sin bandera `g` para evitar el estado interno de `lastIndex` en llamadas repetidas a `.test()`.
* **Usuario (`/^[A-Za-z][A-Za-z0-9]{4,19}$/`):** Exige que el primer carácter sea una letra ASCII (`[A-Za-z]`) y los siguientes 4 a 19 caracteres sean letras ASCII o dígitos (sumando entre 5 y 20 en total).
* **Contraseña (`/^[A-Za-z][A-Za-z0-9_]{7,15}$/`):** Similar al usuario, pero admite guion bajo (`_`) en los caracteres posteriores al inicial, asegurando un total de 8 a 16 caracteres.
* **Teléfono (`/^\+34 [6789]\d{2} \d{3} \d{3}$/`):** Escapa el signo `+` (`\+`), exige espacio literal, un dígito inicial `6, 7, 8 o 9` seguido de dos cifras, y dos bloques adicionales de tres cifras separados por espacio.
* **Código de servicio (`/^(?:DEP)-\d{3}$/`):** Exige el literal exacto en mayúsculas `DEP-` seguido de exactamente 3 dígitos.
* **Referencia de cita (`/^(?:CITA|RES)-\d{4}$/`):** Agrupa sin captura las dos alternativas válidas (`CITA` o `RES`), seguidas de guion y 4 cifras exactas.
* **Extracción de cifras (`/\d+/g`):** Aquí sí se emplea la bandera global `g` junto con `.match()` para capturar todas las secuencias numéricas del texto y no detenerse en la primera coincidencia.

### Formato frente a significado y comparación JS vs `pattern`
* **Formato vs. Significado:** Que un teléfono cumpla `/^\+34 [6789]\d{2} \d{3} \d{3}$/` garantiza que su estructura sintáctica es correcta en España, pero no verifica que la línea exista o pertenezca al usuario. Del mismo modo, en el servidor siempre habría que revalidar todos los datos, tamaños reales de archivo y permisos, ya que el cliente es manipulable.
* **JavaScript vs. `pattern`:** En HTML, el atributo `pattern="DEP-[0-9]{3}"` (escrito sin barras `/` ni banderas) valida la cadena completa automáticamente, pero **no actúa si el campo está vacío** (por eso sigue necesitando `required`). Además, `pattern` solo evalúa cadenas de texto simples y no puede sustituir validaciones complejas como comprobar el tamaño en bytes de un archivo, verificar si un número es entero o calcular si una fecha es posterior al momento actual.