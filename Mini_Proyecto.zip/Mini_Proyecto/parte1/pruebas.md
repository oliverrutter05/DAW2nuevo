# Documentación de Pruebas - Parte 1 (Tema 5A)

## 🚀 Instrucciones para abrir la aplicación
1. Clona o descarga el repositorio del proyecto.
2. Abre la carpeta `parte1/` en tu editor (por ejemplo, VS Code).
3. Utiliza la extensión **Live Server** para abrir el archivo `index.html` en el navegador, o abre directamente `index.html` desde tu explorador de archivos.

---

## 📋 Casos de Prueba

### 1. Obligatoriedad y textos
* **Prueba 1.1: Formulario de socios vacío**
  * **Entrada:** Pulsar el botón "Registrar socio" sin rellenar ningún campo.
  * **Resultado esperado:** El envío se cancela, se marcan los campos obligatorios en rojo, se despliegan mensajes de error con `textContent` y se enfoca el primer campo incorrecto (nombre).
  * **Resultado obtenido:** Correcto. Se enfocó el nombre y aparecieron los errores.
  * **Corrección realizada:** Ninguna (funcionó a la primera).

* **Prueba 1.2: Longitud de texto (Nombre con espacios o fuera de rango)**
  * **Entrada:** Introducir `"   "` (solo espacios) o `"Ana"` (3 caracteres, por debajo del límite de 4).
  * **Resultado esperado:** Mensaje indicando que el nombre es obligatorio o que debe tener entre 4 y 50 caracteres tras `trim()`.
  * **Resultado obtenido:** Correcto. El conteo con `trim()` detectó los espacios y la longitud corta.
  * **Corrección realizada:** Ninguna.

---

### 2. Validación de números
* **Prueba 2.1: Edad con decimales o fuera de rango**
  * **Entrada:** Introducir `17`, `18.5` y `101` en el campo de edad.
  * **Resultado esperado:** Rechazar los valores con mensajes de error personalizados (exigiendo un entero entre 18 y 100 mediante `Number.isInteger` y `valueAsNumber`).
  * **Resultado obtenido:** Correcto. `18.5` dio error por no ser entero y los demás por salir del rango.
  * **Corrección realizada:** Ninguna.

* **Prueba 2.2: Duración en servicios (múltiplos de 15)**
  * **Entrada:** Introducir `14`, `15` y `20` minutos en el formulario de servicios.
  * **Resultado esperado:** `14` y `20` deben fallar; `15` debe ser válido.
  * **Resultado obtenido:** Correcto. La condición `valDuracion % 15 !== 0` funcionó perfectamente.
  * **Corrección realizada:** Ninguna.

---

### 3. Validación de archivos
* **Prueba 3.1: Foto de perfil (Formato y tamaño)**
  * **Entrada:** 
    * Sin archivo (vacío).
    * Subir una imagen `.png` de 1 MB.
    * Subir una imagen `.jpg` de 6.000.000 bytes (supera el límite).
    * Subir una imagen `.jpg` de 2.000.000 bytes (válida).
  * **Resultado esperado:** El formulario debe bloquearse en los tres primeros casos y aceptar únicamente el último JPEG menor a 5 MB.
  * **Resultado obtenido:** Correcto comprobando `files[0].type` y `files[0].size`.
  * **Corrección realizada:** Ninguna.

---

### 4. Fechas y selecciones
* **Prueba 4.1: Fecha de noticias (Posterior a hoy)**
  * **Entrada:** Seleccionar el día de ayer, el día de hoy y mañana.
  * **Resultado esperado:** Ayer y hoy deben mostrar error; mañana debe ser aceptado comparando días locales sin hora.
  * **Resultado obtenido:** Correcto.
  * **Corrección realizada:** Ninguna.

---

### 5. Errores y eventos
* **Prueba 5.1: Envío con la tecla Intro**
  * **Entrada:** Situarse en cualquier input de un formulario y pulsar la tecla Intro.
  * **Resultado esperado:** Se dispara el evento `submit`, se valida el formulario y se muestran los errores correspondientes si los hay.
  * **Resultado obtenido:** Correcto.
  * **Corrección realizada:** Ninguna.

* **Prueba 5.2: Revalidación de contraseña al cambiarla**
  * **Entrada:** Introducir una contraseña, rellenar la confirmación con error, y luego modificar la contraseña principal.
  * **Resultado esperado:** La confirmación se revalida automáticamente en tiempo real gracias al evento `input`.
  * **Resultado obtenido:** Correcto.
  * **Corrección realizada:** Ninguna.